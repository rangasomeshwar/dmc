package com.diagnostic.admin.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "review")
public class ReviewDAO {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "admin_id")
	private Integer adminId;

	@Column(name = "patient_id")
	private Integer patientId;

	private String issue;
	private String quality;
	private String professionalism;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAdminId() {
		return adminId;
	}

	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public String getIssue() {
		return issue;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

	public String getQuality() {
		return quality;
	}

	public void setQuality(String quality) {
		this.quality = quality;
	}

	public String getProfessionalism() {
		return professionalism;
	}

	public void setProfessionalism(String professionalism) {
		this.professionalism = professionalism;
	}

	@Override
	public String toString() {
		return "ReviewDAO [id=" + id + ", adminId=" + adminId + ", patientId=" + patientId + ", issue=" + issue
				+ ", quality=" + quality + ", professionalism=" + professionalism + "]";
	}

}
