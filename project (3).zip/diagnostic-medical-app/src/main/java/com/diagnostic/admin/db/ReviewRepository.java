package com.diagnostic.admin.db;

import org.springframework.data.repository.CrudRepository;

public interface ReviewRepository extends CrudRepository<ReviewDAO,Integer> {
	
	Iterable<ReviewDAO>	findAllByPatientId(Integer patientId);
	Iterable<ReviewDAO> findByAdminId(Integer adminId);
	
}
