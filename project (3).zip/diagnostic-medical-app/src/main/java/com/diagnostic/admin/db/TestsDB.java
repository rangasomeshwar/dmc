package com.diagnostic.admin.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tests")
public class TestsDB {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	private String service;

	@Column(name = "max_value")
	private Integer maxValue;

	@Column(name = "min_value")
	private Integer minValue;

	@Column(name = "doctor_id")
	private Integer doctorId;

	@Column(name = "patient_id")
	private Integer patientId;

	@Column(name = "appointment_id")
	private Integer appointmentId;

	@Column(name = "medical_condition")
	private String medicalCondition;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public Integer getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(Integer maxValue) {
		this.maxValue = maxValue;
	}

	public Integer getMinValue() {
		return minValue;
	}

	public void setMinValue(Integer minValue) {
		this.minValue = minValue;
	}

	public Integer getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public Integer getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getMedicalCondition() {
		return medicalCondition;
	}

	public void setMedicalCondition(String medicalCondition) {
		this.medicalCondition = medicalCondition;
	}

	@Override
	public String toString() {
		return "TestsDB [id=" + id + ", service=" + service + ", maxValue=" + maxValue + ", minValue=" + minValue
				+ ", doctorId=" + doctorId + ", patientId=" + patientId + ", appointmentId=" + appointmentId
				+ ", medicalCondition=" + medicalCondition + "]";
	}

}
