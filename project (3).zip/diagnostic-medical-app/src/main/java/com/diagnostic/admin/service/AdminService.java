package com.diagnostic.admin.service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.diagnostic.admin.db.AdminDAO;
import com.diagnostic.admin.db.AdminRepository;
import com.diagnostic.admin.db.AgentDb;
import com.diagnostic.admin.db.AgentRepository;
import com.diagnostic.admin.db.CommissionDAO;
import com.diagnostic.admin.db.CommissionRepository;
import com.diagnostic.admin.db.ReviewDAO;
import com.diagnostic.admin.db.ReviewRepository;
import com.diagnostic.admin.db.ServiceListRepository;
import com.diagnostic.admin.db.ServicesList;
import com.diagnostic.admin.db.TestsDB;
import com.diagnostic.admin.db.TestsRepository;
import com.diagnostic.doctor.dao.DoctorDAO;
import com.diagnostic.patient.dao.Appointment;
import com.diagnostic.patient.dao.AppointmentRepository;

@Service
public class AdminService {

	@Autowired
	private AdminRepository adminRepo;

	@Autowired
	private ServiceListRepository serviceRepo;

	@Autowired
	private AgentRepository agentRepo;

	@Autowired
	private AppointmentRepository appointmentRepo;

	@Autowired
	private TestsRepository testsRepo;

	@Autowired
	private ReviewRepository reviewRepo;
	
	@Autowired
	private CommissionRepository commissionRepo;

	public Iterable<ServicesList> listOfServices() {
		// Iterable<ServicesList> list = serviceRepo.findAll();
		return serviceRepo.findAll();
	}

	public void createAgent(AgentDb agent) {
		System.out.println(agent);
		// agentRepo.save(agent);
	}

	public void createService(ServicesList servicesList) {
		System.out.println(servicesList);
	}

	public boolean updateService(String name, String contact, String email) {
		Iterable<ServicesList> serviceLists = serviceRepo.findByName(name);
		for (ServicesList servicesList : serviceLists) {
			if (servicesList.getName().equals(name)) {
				servicesList.setEmail(email);
				servicesList.setContact(contact);
				serviceRepo.save(servicesList);
				return true;
			}
		}
		return false;
	}

	public Iterable<Appointment> approvedAppointments() {
		Iterable<Appointment> appointments = appointmentRepo.findByApproval("Approved");
		return appointments;
	}

	public void updateTests(TestsDB tests) {
		System.out.println(tests);
		testsRepo.save(tests);
	}

	public TestsDB viewTestResult(Integer id) {
		Iterable<TestsDB> tests = testsRepo.findByAppointmentId(id);
		for (TestsDB test : tests) {
			if (test.getAppointmentId() == id) {
				return test;
			}
		}
		return null;
	}

	public boolean editTestResult(String id, String value) {
		Integer minValue = Integer.parseInt(value);
		Integer appointmentId = Integer.parseInt(id);
		Iterable<TestsDB> tests = testsRepo.findByAppointmentId(appointmentId);
		for (TestsDB test : tests) {
			if (test.getAppointmentId() == appointmentId) {
				test.setMinValue(minValue);
				testsRepo.save(test);
				return true;
			}
		}
		return false;
	}

	public List<Appointment> completedAppointment() {
		List<Appointment> list = new ArrayList<Appointment>();
		Iterable<Appointment> appointments = appointmentRepo.findByApproval("Approved");
		for (Appointment appointment : appointments) {
			if (appointment.getStatus().equals("Completed") && appointment.getReview().equals("Not Completed")) {
				list.add(appointment);
			}
		}
		return list;
	}

	public Integer returnIdByEmail(String email) {
		Integer id = 0;
		Iterable<AdminDAO> byEmail = adminRepo.findByEmail(email);
		for (AdminDAO admin : byEmail) {
			if (admin.getEmail().equals(email)) {
				id = admin.getId();
			}
		}
		return id;
	}

	public void sendReviewQuetionarie(String email, Integer id) {
		Integer adminId = returnIdByEmail(email);
		ReviewDAO reviewDao = new ReviewDAO();
		Iterable<Appointment> appointments = appointmentRepo.findByApproval("Approved");
		for (Appointment appointment : appointments) {
			if (appointment.getPatientId().equals(id)) {
				appointment.setReview("Completed");
				reviewDao.setAdminId(adminId);
				reviewDao.setPatientId(id);
				reviewDao.setIssue("x");
				reviewDao.setQuality("y");
				reviewDao.setProfessionalism("z");
				reviewRepo.save(reviewDao);
			}
		}
	}

	public List<Appointment> agentsWhoGetCommission() {
		// List<Appointment> list = new ArrayList<>();
		Set<Appointment> set = new HashSet<>();
		Iterable<AgentDb> agents = agentRepo.findAll();
		Integer agentId = 0;
		Iterable<Appointment> appointments = appointmentRepo.findByApproval("Approved");
		for (Appointment appointment : appointments) {
			String str = appointment.getReferal();
			if (str == null) {
				agentId = 0;
			} else {
				agentId = Integer.parseInt(str);
			}
			for (AgentDb agent : agents) {
				if (agent.getId().equals(agentId)) {
					set.add(appointment);
				}
			}
		}
		int n = set.size();
		List<Appointment> list = new ArrayList<>(n);
		for (Appointment appointment : set) {
			list.add(appointment);
		}
		return list;
	}

	public List<Appointment> agentBookingsById(String id) {
		List<Appointment> list = new ArrayList<>();
		DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		Iterable<Appointment> appointments = appointmentRepo.findByApproval("Approved");
		for (Appointment appointment : appointments) {
			String str = appointment.getReferal();
			String dateString = appointment.getDate();
			LocalDate date = LocalDate.parse(dateString, df);
			date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
			Period period = date.until(LocalDate.now());
			if (str == null) {
				str = "";
			} else if (str.equals(id) && period.getDays() <= 7) {
				list.add(appointment);
			}
		}
		return list;
	}
	
	public String addCommission(CommissionDAO commission) {
		String dateString = commission.getDate();
		DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date = LocalDate.parse(dateString, df);
		date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		String dayOfWeek = date.getDayOfWeek().name();
		Iterable<CommissionDAO> commissions = commissionRepo.findAllByAgentId(commission.getAgentId());
//		System.out.println(date.getDayOfWeek());
		if(dayOfWeek.equals("SATURDAY") || dayOfWeek.equals("SUNDAY")) {
			for (CommissionDAO commissionDAO : commissions) {
				System.out.println(commission.getDate());
				String dateInTable = commissionDAO.getDate();
				Integer agentIdInTable = commissionDAO.getAgentId();
				if(dateInTable == null && agentIdInTable == null) {
					commissionRepo.save(commission);
					return "Commission added sucessfully!!!";
				}else if(dateInTable.equals(commission.getDate()) && agentIdInTable.equals(commission.getAgentId()) ) {
					System.out.println(date.getDayOfWeek());
					return "Already added!!!";
				}
			}
			commissionRepo.save(commission);
//			System.out.println(date.getDayOfWeek());
			return "Commission added sucessfully!!!";
		}
		return "You can add commission only on saturday or sunday";
	}
	
	public boolean updateCommission(String name, String commission) {
		Iterable<ServicesList> serviceLists = serviceRepo.findByName(name);
		for (ServicesList servicesList : serviceLists) {
			if (servicesList.getName().equals(name)) {
				servicesList.setCommission(Integer.parseInt(commission));
				serviceRepo.save(servicesList);
				return true;
			}
		}
		return false;
	}
	
	public Iterable<CommissionDAO> listOfAgents() {
		return commissionRepo.findAll();
	}

}
