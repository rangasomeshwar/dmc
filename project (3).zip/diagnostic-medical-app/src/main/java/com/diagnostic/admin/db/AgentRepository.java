package com.diagnostic.admin.db;

import org.springframework.data.repository.CrudRepository;

public interface AgentRepository extends CrudRepository<AgentDb, Integer> {
	
	Iterable<AgentDb> findByEmail(String email);
	
}
