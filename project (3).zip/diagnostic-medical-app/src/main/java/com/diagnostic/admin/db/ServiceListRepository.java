package com.diagnostic.admin.db;

import org.springframework.data.repository.CrudRepository;

public interface ServiceListRepository extends CrudRepository<ServicesList, Integer> {
	Iterable<ServicesList> findByName(String name);
}
