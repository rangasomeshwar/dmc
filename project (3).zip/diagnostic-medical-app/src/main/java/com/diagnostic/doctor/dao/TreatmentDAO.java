package com.diagnostic.doctor.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "treatment")
public class TreatmentDAO {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "appointment_id")
	private Integer appointmentId;

	private String date;
	private String diagnosis;
	private String symptoms;
	private String recommendations;
	private String diet;

	@Column(name = "tests_recommended")
	private String testsRecommended;

	private String prescription;
	private Integer quantity;

	@Column(name = "doctor_id")
	private Integer doctorId;

	@Column(name = "patient_id")
	private Integer patientId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDiagnosis() {
		return diagnosis;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}

	public String getSymptoms() {
		return symptoms;
	}

	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}

	public String getRecommendations() {
		return recommendations;
	}

	public void setRecommendations(String recommendations) {
		this.recommendations = recommendations;
	}

	public String getDiet() {
		return diet;
	}

	public void setDiet(String diet) {
		this.diet = diet;
	}

	public String getTestsRecommended() {
		return testsRecommended;
	}

	public void setTestsRecommended(String testsRecommended) {
		this.testsRecommended = testsRecommended;
	}

	public String getPrescription() {
		return prescription;
	}

	public void setPrescription(String prescription) {
		this.prescription = prescription;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Integer getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	@Override
	public String toString() {
		return "TreatmentDAO [id=" + id + ", appointmentId=" + appointmentId + ", date=" + date + ", diagnosis="
				+ diagnosis + ", symptoms=" + symptoms + ", recommendations=" + recommendations + ", diet=" + diet
				+ ", testsRecommended=" + testsRecommended + ", prescription=" + prescription + ", quantity=" + quantity
				+ ", doctorId=" + doctorId + ", patientId=" + patientId + "]";
	}

}
