package com.diagnostic.doctor.dao;

import org.springframework.data.repository.CrudRepository;

public interface DoctorRepository extends CrudRepository<DoctorDAO, Integer> {
	Iterable<DoctorDAO> findByEmail(String email);
	
	Iterable<DoctorDAO> findAllById(Integer id);
}
