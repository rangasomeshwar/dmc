package com.diagnostic.doctor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.diagnostic.additional.dao.Help;
import com.diagnostic.doctor.dao.TreatmentDAO;
import com.diagnostic.patient.dao.Appointment;

@Controller
@SessionAttributes("email")
public class DoctorController {

	@Autowired
	private DoctorService servcie;

	@RequestMapping(value = "/diagnostic-center/doctorHome", method = RequestMethod.GET)
	public String showDoctorHomePage(ModelMap map) {
		String email = (String) map.get("email");
		// System.out.println(email);
		map.put("email", email);
		return "doctor-home";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/viewAppointmentRequests", method = RequestMethod.GET)
	public String appointmentRequests(ModelMap map) {
		String email = (String) map.get("email");
		map.put("appointments", servcie.viewAppointments(email));
		return "doctor-requests";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/approve", method = RequestMethod.GET)
	public String appointmentApprove(@RequestParam Integer id, ModelMap map) {
		// String email = (String)map.get("email");
		servcie.approveRequest(id);
		return "redirect:/diagnostic-center/doctorHome/viewAppointmentRequests";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/reject", method = RequestMethod.GET)
	public String appointmentReject(@RequestParam Integer id, ModelMap map) {
		servcie.rejectRequest(id);
		return "redirect:/diagnostic-center/doctorHome/viewAppointmentRequests";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/notification", method = RequestMethod.GET)
	public String notification(ModelMap map) {
		// System.out.println(id);
		String email = (String) map.get("email");
		String remainder = servcie.appointmentRemainder(email);
		map.addAttribute("remainder", remainder);
		return "doctor-notify";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/testResults", method = RequestMethod.GET)
	public String testResults(ModelMap map) {
		String email = (String) map.get("email");

		map.put("tests", servcie.viewTestResults(email));
		// map.put("appointments", servcie.viewTestResults(email));
		return "doctor-tests";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/viewTests/patientId", method = RequestMethod.GET)
	public String viewtestResultsByPatientId(ModelMap map, @RequestParam Integer id) {
		map.put("tests", servcie.findByTestsByPatientId(id));
		return "doctor-test-patientId";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/patientRecords", method = RequestMethod.GET)
	public String patientRecordPage(ModelMap map) {
		String email = (String) map.get("email");
		map.put("patients", servcie.viewApprovedAppointments(email));
		return "doctor-patientRecord";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/patientRecords/patientId", method = RequestMethod.GET)
	public String treatmentPage(@RequestParam Integer id, ModelMap map) {
		String email = (String) map.get("email");
		map.put("id", id);
		if(servcie.treatmentcompleted(email, id)) {
			map.put("button", "disabled");
		}
		return "treatment";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/patientRecords/patientId/addTreatment", method = RequestMethod.GET)
	public String showTreatmentForm(@ModelAttribute("treatment") TreatmentDAO treatment) {
		return "treatment-add";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/patientRecords/patientId/addTreatment/confirm", method = RequestMethod.POST)
	public String onSavingTreatmentForm(@ModelAttribute("treatment") TreatmentDAO treatment, BindingResult result,
			ModelMap map) {
		if (result.hasErrors()) {
			return "treatment-add";
		}
		servcie.saveTreatment(treatment);
		// System.out.println(treatment);
		return "redirect:/diagnostic-center/doctorHome/patientRecords";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/patientRecords/patientId/viewTreatment", method = RequestMethod.GET)
	public String viewTreatmentDetails(@RequestParam Integer id, @ModelAttribute("treatments") TreatmentDAO treatment,
			BindingResult result, ModelMap map) {
		String email = (String) map.get("email");
		map.addAttribute("treatments", servcie.viewTreatments(id, email));
		return "treatment-view";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/patientRecords/patientId/updateTreatment", method = RequestMethod.GET)
	public String updateTreatmentDetailsForm(@RequestParam Integer id, ModelMap map) {
		// String email = (String)map.get("email");
		map.put("id", id);
		return "treatment-update-form";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/patientRecords/patientId/updateTreatment/confirm", method = RequestMethod.POST)
	public String updateTreatmentDetails(@RequestParam String treatmentId, @RequestParam String appointmentId,
			@RequestParam String prescription, ModelMap map) {
		String email = (String) map.get("email");
		if (servcie.updaateTreatentDetails(email, treatmentId, appointmentId, prescription)) {
			return "redirect:/diagnostic-center/doctorHome/patientRecords";
		}
		map.put("error", "Appointment ID not found");
		return "treatment-update-form";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/help", method = RequestMethod.GET)
	public String reportTechnicalIssueForm(ModelMap map, @ModelAttribute("help") Help help) {
		return "doctor-help";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/help/raise", method = RequestMethod.POST)
	public String reportTechnicalIssue(@ModelAttribute("help") Help help, ModelMap map, BindingResult result) {
		if (result.hasErrors()) {
			return "redirect:/diagnostic-center/doctorHome/help";
		}
		String email = (String) map.get("email");
		servcie.saveTechnicalReports(email, help);
		map.put("message", "Successfully Reported!!! If issue not resolved, Report Issue on - 1800 100 100");
		return "doctor-help-contact";
	}

	@RequestMapping(value = "/diagnostic-center/doctorHome/patientRecords/patientId/complete", method = RequestMethod.GET)
	public String treatmentCompleted(@RequestParam Integer id, ModelMap map) {
		String email = (String) map.get("email");
		servcie.onTreatmentCompletion(email, id);
		return "redirect:/diagnostic-center/doctorHome/patientRecords";
	}

}
