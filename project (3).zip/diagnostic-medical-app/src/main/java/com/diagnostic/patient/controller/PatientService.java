package com.diagnostic.patient.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.SystemPropertyUtils;

import com.diagnostic.additional.dao.Help;
import com.diagnostic.additional.dao.HelpRepository;
import com.diagnostic.admin.db.ReviewDAO;
import com.diagnostic.admin.db.ReviewRepository;
import com.diagnostic.admin.db.ServiceListRepository;
import com.diagnostic.admin.db.ServicesList;
import com.diagnostic.admin.db.TestsDB;
import com.diagnostic.admin.db.TestsRepository;
import com.diagnostic.doctor.dao.DoctorDAO;
import com.diagnostic.doctor.dao.DoctorRepository;
import com.diagnostic.doctor.dao.TreatmentDAO;
import com.diagnostic.doctor.dao.TreatmentRepository;
import com.diagnostic.patient.dao.Appointment;
import com.diagnostic.patient.dao.AppointmentRepository;
import com.diagnostic.patient.dao.FeedbackDAO;
import com.diagnostic.patient.dao.FeedbackRepository;
import com.diagnostic.patient.dao.PatientDAO;
import com.diagnostic.patient.dao.PatientRepository;

@Service
public class PatientService {

	@Autowired
	private ServiceListRepository serviceRepo;

	@Autowired
	private DoctorRepository docRepo;

	@Autowired
	private PatientRepository patientRepo;
	
	@Autowired
	private TestsRepository testsRepo;
	
	@Autowired
	private TreatmentRepository treatmentRepo;

	@Autowired
	private AppointmentRepository appointmentRepo;
	
	@Autowired
	private HelpRepository helpRepo;
	
	@Autowired
	private FeedbackRepository feedbackRepo;
	
	@Autowired
	private ReviewRepository reviewRepo;

	public Iterable<ServicesList> listOfServices() {
		// ServicesList list = servicelistRepo.findById(1).get();
		Iterable<ServicesList> list = serviceRepo.findAll();
		return list;
	}

	public ServicesList displayServiceOnClickingId(Integer id) {
		ServicesList services = serviceRepo.findById(id).get();
		return services;
	}

	public Iterable<DoctorDAO> listOfDoctors() {
		Iterable<DoctorDAO> doctors = docRepo.findAll();
		return doctors;
	}

	public DoctorDAO displayDoctorOnClickingId(Integer id) {
		DoctorDAO doctor = docRepo.findById(id).get();
		return doctor;
	}

	public Appointment bookAppointment(String email, Appointment appointment) {
		// if(appointment.getStatus().equals(null) ||
		// appointment.getStatus().equalsIgnoreCase(("Not Completed"))) {
		Iterable<PatientDAO> byEmail = patientRepo.findByEmail(email);
		for (PatientDAO patientDAO : byEmail) {
			if (patientDAO.getEmail().equals(email)) {
				Integer id = patientDAO.getId();
				appointment.setPatientId(id);
				appointment.setBook("yes");
				appointment.setApproval("wait");
				appointment.setStatus("Not Completed");
				appointment.setDetails("Waiting for Doctor's Approval!!!");
				// appointmentRepo.save(appointment);
				// System.out.println(appointment);
			}
		}
		appointmentRepo.save(appointment);
		return appointment;
		// return null;
	}

	public List<Appointment> viewApproval(String email) {
		String str = null;
		String approval = null;
		List<Appointment> list = new ArrayList<Appointment>();
		Integer id = returnsIdByEmail(email);
		System.out.println(id);
		Iterable<Appointment> appoinments = appointmentRepo.findByPatientId(id);
		for (Appointment appointment : appoinments) {
			approval = appointment.getApproval();
			// System.out.println(approval);
			if (appointment.getStatus().equals("Not Completed") && approval.equals("wait")) {
				str = "Waiting for Doctor's Approval!!!";
			} else if (approval.equals("Rejected") && appointment.getStatus().equals("Not Completed")) {
				str = "Your request for appointment has been rejected!!!";
			} else if (approval.equals("Approved")
					&& appointment.getStatus().equals("Not Completed")) {
				str = "Your apppointment is confirmed. " + "Appoiontment is scheduled on " + appointment.getDate()
						+ " at " + appointment.getTime();
			} else if (appointment.getStatus().equals("Completed")) {
				str = "No new requests found";
			}else {
				str = "You did not raised a request yet!!!";
			}
			appointment.setDetails(str);
			appointmentRepo.save(appointment);
			list.add(appointment);
		}
		return list;
	}
	
	public Appointment displayAppointmentDetails(Integer id) {
		Appointment appointment = appointmentRepo.findById(id).get();
		return appointment;
	}
	
	public String appointmentRemainder(String email) {
		LocalDate date = LocalDate.now();
		Integer id = returnsIdByEmail(email);
		String approval = "wait";
		DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		Iterable<Appointment> appointments = appointmentRepo.findByPatientId(id);
		for (Appointment appointment : appointments) {
			String str = appointment.getDate();
			approval = appointment.getApproval();
//			System.out.println(str);
			date = LocalDate.parse(str, df);
		}
		if(date.equals(LocalDate.now().plusDays(1)) && approval.equals("Approved")) {
			return "Your appointment is scheduled tomorrow";
		}else{
			return "No new notification";
		}
	}

	public Integer returnsIdByEmail(String email) {
		Integer id = 0;
		Iterable<PatientDAO> byEmail = patientRepo.findByEmail(email);
		for (PatientDAO patientDAO : byEmail) {
			if (patientDAO.getEmail().equals(email)) {
				id = patientDAO.getId();
			}
		}
		return id;
	}

	public Iterable<TestsDB> viewTestResults(String email) {
		Iterable<PatientDAO> patients = patientRepo.findByEmail(email);
		Integer id = 0;
		for (PatientDAO patient : patients) {
			if(patient.getEmail().equals(email)) {
				id = patient.getId();
			}
		}
		return testsRepo.findAllByPatientId(id);
	}

	public TestsDB findByTestsByTestId(Integer id){
		 return testsRepo.findById(id).get();
	}
	
	public Iterable<TreatmentDAO> viewTreatments(String email){
		Integer patientId = returnsIdByEmail(email);
		return treatmentRepo.findAllByPatientId(patientId);
	}
	
	public void saveTechnicalReports(String email, Help help) {
		Integer id = returnsIdByEmail(email);
		help.setUserId(id);
		help.setStatus("Open");
		helpRepo.save(help);
	}
	
	public String saveFeedback(String email, FeedbackDAO feedbackDAO) {
		Integer id = returnsIdByEmail(email);
		feedbackDAO.setPatientId(id);
		Integer doctorId = feedbackDAO.getDoctorId();
		DoctorDAO doctorDAO = docRepo.findById(doctorId).get();
		if(doctorDAO.getId().equals(doctorId)) {
//			System.out.println(feedbackDAO);
			Iterable<FeedbackDAO> patients = feedbackRepo.findAllByPatientId(id);
			for (FeedbackDAO feedback : patients) {
				if(feedback.getDoctorId().equals(doctorId)) {
					return "You have already submitted your feedback!!!";
				}
			}
			feedbackRepo.save(feedbackDAO);
			return "feedback saved!!!";
		}
		return "Doctor ID not found";
	}
	
	public boolean testReview(String email) {
		Integer id = returnsIdByEmail(email);
		Iterable<Appointment> appointments = appointmentRepo.findByApproval("Approved");
		for (Appointment appointment : appointments) {
			if(appointment.getPatientId().equals(id) && appointment.getReview().equals("Completed")) {
				return true;
			}
		}
		return false;
	}
	
	public String reviewByPatient(String email, ReviewDAO reviewDAO) {
		Integer id = returnsIdByEmail(email);
		Iterable<ReviewDAO> reviews = reviewRepo.findAllByPatientId(id);
		for (ReviewDAO review : reviews) {
			if(review.getIssue().equals("x") && review.getQuality().equals("y") && review.getProfessionalism().equals("z")) {
				review.setIssue(reviewDAO.getIssue());
				review.setQuality(reviewDAO.getQuality());
				review.setProfessionalism(reviewDAO.getProfessionalism());
				reviewRepo.save(review);
				return "review saved!!";
			}
		}
		return "already saved";
	}

}
