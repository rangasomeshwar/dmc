package com.diagnostic.patient.controller;

import java.util.List;

import javax.naming.Binding;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.diagnostic.additional.dao.Help;
import com.diagnostic.admin.db.ReviewDAO;
import com.diagnostic.admin.db.ServiceListRepository;
import com.diagnostic.admin.db.ServicesList;
import com.diagnostic.controller.LoginService;
import com.diagnostic.doctor.dao.DoctorDAO;
import com.diagnostic.patient.dao.Appointment;
import com.diagnostic.patient.dao.FeedbackDAO;

@Controller
@SessionAttributes("email")
public class PatientController {

	@Autowired
	private ServiceListRepository serviceRepo;

	@Autowired
	private PatientService service;

	@Autowired
	private LoginService loginService;

	@RequestMapping(value = "/diagnostic-center/patientHome", method = RequestMethod.GET)
	public String showPatientHomePage(ModelMap map) {
		String email = (String) map.get("email");
		// System.out.println(email);
		if (!service.testReview(email)) {
			map.put("button", "disabled");
		}
		map.put("email", email);
		return "patient-home";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/listOfServices", method = RequestMethod.GET)
	public String showServicesPage(ModelMap map) {
		map.put("services", service.listOfServices());
		return "patient-services";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/service", method = RequestMethod.GET)
	public String serviceById(@RequestParam Integer id, @ModelAttribute("service") ServicesList serviceList,
			ModelMap map) {
		// System.out.println(id);
		ServicesList services = service.displayServiceOnClickingId(id);
		// System.out.println(services);
		map.addAttribute("service", services);
		return "service-details";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/listOfDoctors", method = RequestMethod.GET)
	public String showDoctorsList(ModelMap map) {
		map.put("doctors", service.listOfDoctors());
		return "doctor-details";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/doctor", method = RequestMethod.GET)
	public String doctorById(ModelMap map, @RequestParam Integer id, @ModelAttribute("doctor") DoctorDAO doctors) {
		// System.out.println(id);
		DoctorDAO doctor = service.displayDoctorOnClickingId(id);
		map.addAttribute("doctor", doctor);
		return "doctor-id";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/bookAppointment", method = RequestMethod.GET)
	public String bookAppointment(@ModelAttribute("appointment") Appointment appointment) {
		return "appointment-request";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/bookAppointment/confirm", method = RequestMethod.POST)
	public String bookAppointmentConfirm(@ModelAttribute("appointment") Appointment appointment, BindingResult result,
			ModelMap map) {

		if (result.hasErrors()) {
			return "appointment-request";
		}
		String email = (String) map.get("email");
		// System.out.println(email);
		service.bookAppointment(email, appointment);
		map.addAttribute("appointment", appointment);
		map.addAttribute("message", "Request for appointment sucessfully raised");
		System.out.println(appointment);
		return "redirect:/diagnostic-center/patientHome";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/viewAppointmentStatus", method = RequestMethod.GET)
	public String appointmentStatus(ModelMap map) {
		String email = (String) map.get("email");
		map.put("appointments", service.viewApproval(email));
		return "appointment-status";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/status", method = RequestMethod.GET)
	public String appointmentById(ModelMap map, @RequestParam Integer id,
			@ModelAttribute("appointment") Appointment appointments) {
		// System.out.println(id);
		Appointment appointment = service.displayAppointmentDetails(id);
		map.addAttribute("appointment", appointment);
		return "appointment-id";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/notification", method = RequestMethod.GET)
	public String notification(ModelMap map) {
		// System.out.println(id);
		String email = (String) map.get("email");
		String remainder = service.appointmentRemainder(email);
		map.addAttribute("remainder", remainder);
		return "patient-notify";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/tests", method = RequestMethod.GET)
	public String testResults(ModelMap map) {
		String email = (String) map.get("email");
		map.put("tests", service.viewTestResults(email));
		return "patient-tests";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/viewTests/patientId", method = RequestMethod.GET)
	public String viewtestResultsByPatientId(ModelMap map, @RequestParam Integer id) {
		map.put("test", service.findByTestsByTestId(id));
		return "patient-testID";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/viewTreatment", method = RequestMethod.GET)
	public String viewTreatment(ModelMap map) {
		String email = (String) map.get("email");
		map.put("treatments", service.viewTreatments(email));
		return "patient-treatment-view";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/help", method = RequestMethod.GET)
	public String reportTechnicalIssueForm(ModelMap map, @ModelAttribute("help") Help help) {
		return "patient-help";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/help/raise", method = RequestMethod.POST)
	public String reportTechnicalIssue(@ModelAttribute("help") Help help, ModelMap map, BindingResult result) {
		if (result.hasErrors()) {
			return "redirect:/diagnostic-center/patientHome/help";
		}
		String email = (String) map.get("email");
		service.saveTechnicalReports(email, help);
		map.put("message", "Successfully Reported!!! If issue not resolved, Report Issue on - 1800 100 100");
		return "patient-help-contact";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/feedback", method = RequestMethod.GET)
	public String showFeedbackForm(ModelMap map, @ModelAttribute("feedback") FeedbackDAO feedback) {
		return "feedback-form";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/feedback/confirm", method = RequestMethod.POST)
	public String saveFeedback(@ModelAttribute("feedback") FeedbackDAO feedback, ModelMap map, BindingResult result) {
		if (result.hasErrors()) {
			return "feedback-from";
		}
		String email = (String) map.get("email");
		String message = service.saveFeedback(email, feedback);
		map.put("message", message);
		return "feedback-form";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/review", method = RequestMethod.GET)
	public String reviewForm(ModelMap map, @ModelAttribute("review") ReviewDAO review) {
		// String email = (String)map.get("email");
		return "review-form";
	}

	@RequestMapping(value = "/diagnostic-center/patientHome/review/submit", method = RequestMethod.POST)
	public String reviewFormSubmit(ModelMap map, @ModelAttribute("review") ReviewDAO review) {
		String email = (String) map.get("email");
		String status = service.reviewByPatient(email, review);
		if (status.equals("review saved!!")) {
			map.put("message", status);
		} else {
			map.put("message", status);
		}
		return "review-form";
	}

	@ModelAttribute("serviceList")
	public List<String> populateServices() {
		List<String> services = loginService.services();
		return services;
	}

}
