package com.diagnostic.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.diagnostic.admin.db.AdminDAO;
import com.diagnostic.admin.db.AdminRepository;
import com.diagnostic.admin.db.AgentDb;
import com.diagnostic.admin.db.AgentRepository;
import com.diagnostic.admin.db.ServiceListRepository;
import com.diagnostic.admin.db.ServicesList;
import com.diagnostic.doctor.dao.DoctorDAO;
import com.diagnostic.doctor.dao.DoctorRepository;
import com.diagnostic.patient.dao.PatientDAO;
import com.diagnostic.patient.dao.PatientRepository;

@Service
public class LoginService {

	@Autowired
	private PatientRepository patientRepo;

	@Autowired
	private AdminRepository adminRepo;

	@Autowired
	private DoctorRepository doctorRepo;

	@Autowired
	private AgentRepository agentRepo;

	@Autowired
	private ServiceListRepository serviceRepo;

	public String checkLogin(String email, String password) {
		Iterable<PatientDAO> patientList = patientRepo.findByEmail(email);
		for (PatientDAO patientDAO : patientList) {
			if (patientDAO.getEmail().equals(email) && patientDAO.getPassword().equals(password)) {
				return "patient";
			}
		}
		Iterable<AdminDAO> adminList = adminRepo.findByEmail(email);
		for (AdminDAO adminDAO : adminList) {
			if (adminDAO.getEmail().equals(email) && adminDAO.getPassword().equals(password)) {
				return "admin";
			}
		}
		Iterable<DoctorDAO> doctorList = doctorRepo.findByEmail(email);
		for (DoctorDAO doctorDAO : doctorList) {
			if (doctorDAO.getEmail().equals(email) && doctorDAO.getPassword().equals(password)) {
				return "doctor";
			}
		}
		Iterable<AgentDb> agentList = agentRepo.findByEmail(email);
		for (AgentDb agentDb : agentList) {
			if (agentDb.getEmail().equals(email) && agentDb.getPassword().equals(password)) {
				return "agent";
			}
		}
		return "none";

	}

	public void createDoctor(DoctorDAO doctor) {
		doctorRepo.save(doctor);
		System.out.println(doctor);
	}

	public void createPatient(PatientDAO patient) {
		patientRepo.save(patient);
		System.out.println(patient);
	}

	public String forgetPassword(String email, String sport, String father, String born) {
		Iterable<DoctorDAO> doctors = doctorRepo.findByEmail(email);
		for (DoctorDAO doctorDAO : doctors) {
			if (doctorDAO.getEmail().equals(email) && doctorDAO.getSport().equals(sport)
					&& doctorDAO.getFather().equals(father) && doctorDAO.getBorn().equals(born)) {
				return "doctor";
			}
		}
		Iterable<PatientDAO> patients = patientRepo.findByEmail(email);
		for (PatientDAO patientDAO : patients) {
			if (patientDAO.getEmail().equals(email) && patientDAO.getSport().equals(sport)
					&& patientDAO.getFather().equals(father) && patientDAO.getBorn().equals(born)) {
				return "patient";
			}
		}
		return "none";
	}
	
	public boolean resetPassword(String email, String password1, String password2) {
		if(password1.equals(password2)) {
			Iterable<DoctorDAO> doctors = doctorRepo.findByEmail(email);
			for (DoctorDAO doctorDAO : doctors) {
				if (doctorDAO.getEmail().equals(email)) {
					doctorDAO.setPassword(password1);
					doctorRepo.save(doctorDAO);
					return true;
				}
			}
			Iterable<PatientDAO> patients = patientRepo.findByEmail(email);
			for (PatientDAO patientDAO : patients) {
				if (patientDAO.getEmail().equals(email)) {
					patientDAO.setPassword(password1);
					patientRepo.save(patientDAO);
					return true;
				}
			}
		}
		return false;
	}

	public List<String> services() {
		List<String> list = new ArrayList<String>();
		Iterable<ServicesList> services = serviceRepo.findAll();
		for (ServicesList servicesList : services) {
			list.add(servicesList.getName());
		}
		return list;
	}
}
