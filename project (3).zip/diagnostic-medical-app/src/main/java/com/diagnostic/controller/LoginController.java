package com.diagnostic.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.diagnostic.additional.dao.Help;
import com.diagnostic.doctor.dao.DoctorDAO;
import com.diagnostic.patient.dao.PatientDAO;

@Controller
@SessionAttributes("email")
public class LoginController {

	@Autowired
	private LoginService service;

	@RequestMapping("/diagnostic-center")
	public String showLogin(ModelMap model) {
		return "welcome";
	}

	@RequestMapping(value = "/diagnostic-center/home", method = RequestMethod.POST)
	public String onSucessfulLogin(@RequestParam String email, @RequestParam String password, ModelMap map) {
		map.get("email");
		String checkLogin = service.checkLogin(email, password);
		if (checkLogin.equals("admin")) {
			return "adminhome";
		} else if (checkLogin.equals("patient")) {
			map.put("email", email);
			return "patient-home";
		} else if (checkLogin.equals("doctor")) {
			map.put("email", email);
			return "doctor-home";
		} else if (checkLogin.equals("agent")) {
			map.put("email", email);
			return "agent-home";
		} else {
			map.put("error", "Incorrect Credentials");
			return "welcome";
		}
	}

	@RequestMapping("/diagnostic-center/patient-registration")
	public String showPatientRegPage(@ModelAttribute("patient") PatientDAO patient) {
		return "patient-reg";
	}

	@RequestMapping(value = "/diagnostic-center/patient-registration/succes", method = RequestMethod.POST)
	public String onSucessPatientRegPage(@ModelAttribute("patient") PatientDAO patient, BindingResult result,
			ModelMap map) {
		if (result.hasErrors()) {
			return "patient-reg";
		}
		service.createPatient(patient);
		map.addAttribute("patient", patient);
		map.put("succes", "You succesfully signed up!! Go to Login Page");
		return "redirect:/diagnostic-center/patient-registration";
	}

	@RequestMapping("/diagnostic-center/doctor-registration")
	public String showDoctorRegPage(@ModelAttribute("doctor") DoctorDAO doctor) {
		return "doctor-reg";
	}

	@RequestMapping(value = "/diagnostic-center/doctor-registration/succes", method = RequestMethod.POST)
	public String onSucessDoctorRegPage(@ModelAttribute("doctor") DoctorDAO doctor, BindingResult result,
			ModelMap map) {
		if (result.hasErrors()) {
			return "doctor-reg";
		}
		service.createDoctor(doctor);
		map.addAttribute("doctor", doctor);
		map.put("succes", "You succesfully signed up!! Go to Login Page");
		return "redirect:/diagnostic-center/doctor-registration";
	}

	@RequestMapping(value = "/forgetPassword", method = RequestMethod.GET)
	public String forgetPasswordForm(ModelMap map, @ModelAttribute("help") Help help) {
		return "forget-password";
	}

	@RequestMapping(value = "/forgetPassword/passwordReset", method = RequestMethod.POST)
	public String forgetPassword(@RequestParam String email, @RequestParam String sport, @RequestParam String father,
			@RequestParam String born, ModelMap map) {
		String role = service.forgetPassword(email, sport, father, born);
		if (role.equals("none")) {
			map.put("error", "Details doesn't match");
			return "forget-password";
		}
		map.put("email", email);
		return "reset-password";
	}

	@RequestMapping(value = "/forgetPassword/passwordReset/success", method = RequestMethod.POST)
	public String resetPassword(@RequestParam String email,@RequestParam String password1, @RequestParam String password2, ModelMap map) {
//		System.out.println(email);
		if(service.resetPassword(email, password1, password2)){
			map.put("message", email);
			return "reset-success";
		}
		map.put("error", "Passwords doesn't match");
		return "reset-password";
	}

	@ModelAttribute("qualifications")
	public Map<String, String> populateQualification() {
		Map<String, String> qualifications = new HashMap<>();
		qualifications.put("MBBS", "MBBS");
		qualifications.put("B.Med", "B.Med");
		qualifications.put("DDCM", "DCM");
		qualifications.put("MD", "MD");
		qualifications.put("MCM", "MCM");
		return qualifications;
	}

	@ModelAttribute("serviceList")
	public List<String> populateServices() {
		List<String> services = service.services();
		return services;
	}

}
