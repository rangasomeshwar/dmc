package com.diagnostic.agent.controller;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.diagnostic.additional.dao.Help;
import com.diagnostic.additional.dao.HelpRepository;
import com.diagnostic.admin.db.AgentDb;
import com.diagnostic.admin.db.AgentRepository;
import com.diagnostic.admin.db.CommissionDAO;
import com.diagnostic.admin.db.CommissionRepository;
import com.diagnostic.patient.dao.Appointment;
import com.diagnostic.patient.dao.AppointmentRepository;
import com.diagnostic.patient.dao.PatientDAO;
import com.diagnostic.patient.dao.PatientRepository;

@Service
public class AgentService {
	
	@Autowired
	private PatientRepository patientRepo;
	
	@Autowired
	private AppointmentRepository appointmentRepo;
	
	@Autowired
	private AgentRepository agentRepo;
	
	@Autowired
	private HelpRepository helpRepo;
	
	@Autowired
	private CommissionRepository commissionRepo;

	public void createPatient(PatientDAO patient) {
		patientRepo.save(patient);
		System.out.println(patient);
	}
	
	public Integer returnsIdByEmail(String email) {
		Integer id = 0;
		Iterable<AgentDb> byEmail = agentRepo.findByEmail(email);
		for (AgentDb agent : byEmail) {
			if (agent.getEmail().equals(email)) {
				id = agent.getId();
			}
		}
		return id;
	}
	
	public Appointment bookAppointment(String email, Appointment appointment) {
		Integer agentId = returnsIdByEmail(email);
		if(appointment.getReferal().equals(Integer.toString(agentId))) {
			appointment.setBook("yes");
			appointment.setApproval("wait");
			appointment.setStatus("Not Completed");
			appointment.setDetails("Waiting for Doctor's Approval!!!");
		}
		appointmentRepo.save(appointment);
		return appointment;
	}

	public List<Appointment> viewApproval(String email) {
		String str = null;
		String approval = null;
		List<Appointment> list = new ArrayList<Appointment>();
		Integer id = returnsIdByEmail(email);
		Iterable<Appointment> appointments = appointmentRepo.findAllByReferal(Integer.toString(id));
//		System.out.println(id);
		for (Appointment appointment : appointments) {
			approval = appointment.getApproval();
			if (appointment.getStatus().equals("Not Completed") && approval.equals("wait")) {
				str = "Waiting for Doctor's Approval!!!";
			} else if (approval.equals("Rejected") && appointment.getStatus().equals("Not Completed")) {
				str = "Your request for appointment has been rejected!!!";
			} else if (approval.equals("Approved")
					&& appointment.getStatus().equals("Not Completed")) {
				str = "Your apppointment is confirmed. " + "Appoiontment is scheduled on " + appointment.getDate()
						+ " at " + appointment.getTime();
			} else if (appointment.getStatus().equals("Completed")) {
				str = "No new requests found";
			}else {
				str = "You did not raised a request yet!!!";
			}
			appointment.setDetails(str);
			appointmentRepo.save(appointment);
			list.add(appointment);
		}
		return list;
	}
	
	public void saveTechnicalReports(String email, Help help) {
		Integer id = returnsIdByEmail(email);
		help.setUserId(id);
		help.setStatus("Open");
		helpRepo.save(help);
	}
	
	public List<Appointment> agentBookingsById(String email) {
		int id = returnsIdByEmail(email);
		System.out.println(id);
		List<Appointment> list = new ArrayList<>();
		DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		Iterable<Appointment> appointments = appointmentRepo.findByApproval("Approved");
		for (Appointment appointment : appointments) {
			String str = appointment.getReferal();
			String dateString = appointment.getDate();
			LocalDate date = LocalDate.parse(dateString, df);
			date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
			Period period = date.until(LocalDate.now());
			System.out.println(appointment);
			if (str == null) {
				str = "";
			} else if (str.equals(Integer.toString(id)) && period.getDays() <= 7) {
				list.add(appointment);
			}
		}
		System.out.println(list);
		return list;
	}
	
	public Iterable<CommissionDAO> viewCommission(String email){
		Integer agentId = returnsIdByEmail(email);
		return commissionRepo.findAllByAgentId(agentId);
	}
	
}
