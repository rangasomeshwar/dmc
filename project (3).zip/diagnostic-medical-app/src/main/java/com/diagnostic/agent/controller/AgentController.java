package com.diagnostic.agent.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.diagnostic.additional.dao.Help;
import com.diagnostic.admin.db.ServicesList;
import com.diagnostic.admin.service.AdminService;
import com.diagnostic.controller.LoginService;
import com.diagnostic.doctor.dao.DoctorDAO;
import com.diagnostic.patient.controller.PatientService;
import com.diagnostic.patient.dao.Appointment;
import com.diagnostic.patient.dao.PatientDAO;

@Controller
@SessionAttributes("email")
public class AgentController {

	@Autowired
	private PatientService patientService;
	
	@Autowired
	private LoginService loginService;

	@Autowired
	private AgentService service;
	
	@Autowired
	private AdminService adminService;

	@RequestMapping(value = "/diagnostic-center/agentHome", method = RequestMethod.GET)
	public String showAgentHomePage(ModelMap map) {
		String email = (String) map.get("email");
		// System.out.println(email);
		map.put("email", email);
		return "agent-home";
	}

	@RequestMapping(value = "/diagnostic-center/agentHome/listOfServices", method = RequestMethod.GET)
	public String showServicesPage(ModelMap map) {
		map.put("services", patientService.listOfServices());
		return "agent-services";
	}

	@RequestMapping(value = "/diagnostic-center/agentHome/service", method = RequestMethod.GET)
	public String serviceById(@RequestParam Integer id, @ModelAttribute("service") ServicesList serviceList,
			ModelMap map) {
		// System.out.println(id);
		ServicesList services = patientService.displayServiceOnClickingId(id);
		map.addAttribute("service", services);
		return "agent-service-details";
	}

	@RequestMapping(value = "/diagnostic-center/agentHome/listOfDoctors", method = RequestMethod.GET)
	public String showDoctorsList(ModelMap map) {
		map.put("doctors", patientService.listOfDoctors());
		return "agent-doctor-details";
	}

	@RequestMapping(value = "/diagnostic-center/agentHome/doctor", method = RequestMethod.GET)
	public String doctorById(ModelMap map, @RequestParam Integer id, @ModelAttribute("doctor") DoctorDAO doctors) {
		// System.out.println(id);
		DoctorDAO doctor = patientService.displayDoctorOnClickingId(id);
		map.addAttribute("doctor", doctor);
		return "agent-doctor-id";
	}
	
	@RequestMapping(value = "/diagnostic-center/agentHome/bookAppointment", method = RequestMethod.GET)
	public String bookAppointmentForm(@ModelAttribute("appointment") Appointment appointment) {
		return "agent-appointment-request";
	}
	
	@RequestMapping(value = "/diagnostic-center/agentHome/bookAppointment/confirm", method = RequestMethod.POST)
	public String bookAppointmentConfirm(@ModelAttribute("appointment") Appointment appointment,BindingResult result, ModelMap map) {
		
		if(result.hasErrors()) {
			return "agent-appointment-request";
		}
		String email = (String)map.get("email");
		service.bookAppointment(email,appointment);
		map.addAttribute("appointment",appointment);
		map.addAttribute("message","Request for appointment sucessfully raised");
//		System.out.println(appointment);
		return "redirect:/diagnostic-center/agentHome";
	}
	
	@RequestMapping(value = "/diagnostic-center/agentHome/viewAppointmentStatus", method = RequestMethod.GET)
	public String appointmentStatus(ModelMap map) {
		String email = (String)map.get("email");
		map.put("appointments", service.viewApproval(email));
		return "agent-appointment-status";
	}
	
	@RequestMapping(value = "/diagnostic-center/agentHome/status", method = RequestMethod.GET)
	public String appointmentById(ModelMap map, @RequestParam Integer id, @ModelAttribute ("appointment") Appointment appointments) {
//		System.out.println(id);
		Appointment appointment = patientService.displayAppointmentDetails(id);
		map.addAttribute("appointment", appointment);
		return "agent-appointment-id";
	}
	
	@RequestMapping(value = "/diagnostic-center/agentHome/help", method = RequestMethod.GET)
	public String reportTechnicalIssueForm(ModelMap map, @ModelAttribute ("help") Help help) {
		return "agent-help";
	}
	
	@RequestMapping(value = "/diagnostic-center/agentHome/help/raise", method = RequestMethod.POST)
	public String reportTechnicalIssue(@ModelAttribute ("help") Help help , ModelMap map, BindingResult result ) {
		if(result.hasErrors()) {
			return "redirect:/diagnostic-center/agentHome/help";
		}
		String email = (String)map.get("email");
		service.saveTechnicalReports(email, help);
		map.put("message", "Successfully Reported!!! If issue not resolved, Report Issue on - 1800 100 100");
		return "agent-help-contact";
	}
	
	
	@ModelAttribute("serviceList")
	public List<String> populateServices() {
		List<String> services = loginService.services();
		return services;
	}
	
	@RequestMapping(value = "/diagnostic-center/agentHome/commission", method = RequestMethod.GET)
	public String viewCommissionDetails(@ModelAttribute("appointments") Appointment appointment,ModelMap map) {
		String email = (String)map.get("email");
		map.addAttribute("appointments", service.agentBookingsById(email));
		map.addAttribute("services", patientService.listOfServices());
		map.addAttribute("commissions", service.viewCommission(email));
		return "agent-book";
	}

}
