package com.diagnostic;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.diagnostic.admin.db.AgentDb;
import com.diagnostic.admin.db.AgentRepository;
import com.diagnostic.doctor.dao.DoctorDAO;
import com.diagnostic.doctor.dao.DoctorRepository;
import com.diagnostic.patient.dao.PatientDAO;
import com.diagnostic.patient.dao.PatientRepository;

@SpringBootTest
class DiagnosticMedicalAppApplicationTests {

	@Autowired
	private PatientRepository patientRepo;

	@Autowired
	private DoctorRepository docRepo;

	@Autowired
	private AgentRepository agentRepo;

	@Test
	void readingDataFromPatients() {
		Iterable<PatientDAO> patients = patientRepo.findAll();
		System.out.println(patients);
	}

	@Test
	void readingDataFromDcotors() {
		Iterable<DoctorDAO> doctors = docRepo.findAll();
		System.out.println(doctors);
	}

	@Test
	void readingAgentFromAgent() {
		Iterable<AgentDb> agents = agentRepo.findAll();
		System.out.println(agents);
	}

}
