package com.diagnostic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiagnosticMedicalAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
