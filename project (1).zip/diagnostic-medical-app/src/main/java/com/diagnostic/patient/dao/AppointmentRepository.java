package com.diagnostic.patient.dao;

import org.springframework.data.repository.CrudRepository;

public interface AppointmentRepository extends CrudRepository<Appointment, Integer> {
	
	Iterable<Appointment> findByPatientId(Integer patientId);

	Iterable<Appointment> findByDoctorId(Integer doctorId);
	
	Iterable<Appointment> findByApproval(String approval);
	
 	Iterable<Appointment> findAllByReferal(String referal);
	
	
}
