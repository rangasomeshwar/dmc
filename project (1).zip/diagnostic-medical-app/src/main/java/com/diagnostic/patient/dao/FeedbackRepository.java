package com.diagnostic.patient.dao;

import org.springframework.data.repository.CrudRepository;

public interface FeedbackRepository extends CrudRepository<FeedbackDAO, Integer> {
	
	Iterable<FeedbackDAO> findAllByPatientId(Integer patientId);
	
	Iterable<FeedbackDAO> findAllByDoctorId(Integer doctorId);
	
}
