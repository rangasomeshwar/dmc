package com.diagnostic.patient.dao;

import org.springframework.data.repository.CrudRepository;

public interface PatientRepository extends CrudRepository<PatientDAO, Integer> {
	Iterable<PatientDAO> findByEmail(String email);
}
