package com.diagnostic.doctor.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.crypto.dom.DOMCryptoContext;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.diagnostic.additional.dao.Help;
import com.diagnostic.additional.dao.HelpRepository;
import com.diagnostic.admin.db.ServiceListRepository;
import com.diagnostic.admin.db.TestsDB;
import com.diagnostic.admin.db.TestsRepository;
import com.diagnostic.doctor.dao.DoctorDAO;
import com.diagnostic.doctor.dao.DoctorRepository;
import com.diagnostic.doctor.dao.TreatmentDAO;
import com.diagnostic.doctor.dao.TreatmentRepository;
import com.diagnostic.patient.dao.Appointment;
import com.diagnostic.patient.dao.AppointmentRepository;
import com.diagnostic.patient.dao.PatientDAO;
import com.diagnostic.patient.dao.PatientRepository;

@Service
public class DoctorService {

	@Autowired
	private ServiceListRepository serviceRepo;

	@Autowired
	private DoctorRepository docRepo;

	@Autowired
	private PatientRepository patientRepo;

	@Autowired
	private AppointmentRepository appointmentRepo;

	@Autowired
	private TestsRepository testsRepo;

	@Autowired
	private TreatmentRepository treatmentRepo;
	
	@Autowired
	private HelpRepository helpRepo;

	public List<Appointment> viewAppointments(String email) {
		Integer id = returnIdByEmail(email);
		List<Appointment> list = new ArrayList<Appointment>();
		Iterable<Appointment> doctorAppointments = appointmentRepo.findByDoctorId(id);
		for (Appointment appointment : doctorAppointments) {
			if (appointment.getApproval().equals("wait") && appointment.getStatus().equals("Not Completed")) {
				list.add(appointment);
			}
		}
		return list;
	}

	public Integer returnIdByEmail(String email) {
		Integer id = 0;
		Iterable<DoctorDAO> byEmail = docRepo.findByEmail(email);
		for (DoctorDAO docDAO : byEmail) {
			if (docDAO.getEmail().equals(email)) {
				id = docDAO.getId();
			}
		}
		return id;
	}

	public void approveRequest(Integer id) {
		Appointment appointment = appointmentRepo.findById(id).get();
		String str = "Waiting for Doctor's Approval!!!";
		if (appointment.getApproval().equals("Approved") && appointment.getStatus().equals("Not Completed")) {
			str = "Your apppointment is confirmed. " + "Appoiontment is scheduled on " + appointment.getDate() + " at "
					+ appointment.getTime();
		}
		appointment.setApproval("Approved");
		appointment.setDetails(str);
		appointmentRepo.save(appointment);
	}

	public void rejectRequest(Integer id) {
		Appointment appointment = appointmentRepo.findById(id).get();
		String str = "Waiting for Doctor's Approval!!!";
		if (appointment.getApproval().equals("Rejected") && appointment.getStatus().equals("Not Completed")) {
			str = "Your request for appointment has been rejected!!!";
		}
		appointment.setApproval("Rejected");
		appointment.setDetails(str);
		appointmentRepo.save(appointment);
	}

	public String appointmentRemainder(String email) {
		LocalDate date = LocalDate.now();
		Integer id = returnIdByEmail(email);
		String approval = "wait";
		int count = 0;
		DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		Iterable<Appointment> appointments = appointmentRepo.findByDoctorId(id);
		for (Appointment appointment : appointments) {
			if (appointment.getApproval().equals("Approved")) {
				String str = appointment.getDate();
				approval = appointment.getApproval();
				// System.out.println(str);
				date = LocalDate.parse(str, df);
				count++;
			}
		}
		if (date.equals(LocalDate.now().plusDays(1)) && approval.equals("Approved")) {
			if (count == 1) {
				return "You have an appointment scheduled tomorrow";
			} else {
				return "You have " + count + " appointments scheduled tomorrow";
			}
		} else {
			return "No new notification";
		}
	}

	public Iterable<TestsDB> viewTestResults(String email) {
		Iterable<DoctorDAO> doctors = docRepo.findByEmail(email);
		Integer doctorId = 0;
		for (DoctorDAO doctor : doctors) {
			if (doctor.getEmail().equals(email)) {
				doctorId = doctor.getId();
			}
		}
		Iterable<TestsDB> byDoctorId = testsRepo.findAllByDoctorId(doctorId);
		return byDoctorId;
	}

	public Iterable<TestsDB> findByTestsByPatientId(Integer id) {
		return testsRepo.findAllByPatientId(id);
	}

	public List<Appointment> viewApprovedAppointments(String email) {
		Iterable<DoctorDAO> doctors = docRepo.findByEmail(email);
		Integer doctorId = 0;
		for (DoctorDAO doctor : doctors) {
			if (doctor.getEmail().equals(email)) {
				doctorId = doctor.getId();
			}
		}
		List<Appointment> list = new ArrayList<>();
		Iterable<Appointment> appoinments = appointmentRepo.findByDoctorId(doctorId);
		for (Appointment appointment : appoinments) {
			if (appointment.getApproval().equals("Approved")) {
				list.add(appointment);
			}
		}
		return list;
	}

	public void saveTreatment(TreatmentDAO treatment) {
		// System.out.println(treatment);
		treatmentRepo.save(treatment);
	}

	public List<TreatmentDAO> viewTreatments(Integer patientId, String email) {
		Integer doctorId = returnIdByEmail(email);
		List<TreatmentDAO> list = new ArrayList<>();
		Iterable<TreatmentDAO> treatments = treatmentRepo.findAllByDoctorId(doctorId);
		System.out.println(treatments);
		for (TreatmentDAO treatment : treatments) {
			if(treatment.getPatientId().equals(patientId)) {
				list.add(treatment);
			}
		}
		return list;
	}

	public boolean updaateTreatentDetails(String email, String treatmentId, String appId, String prescription) {
		Integer doctorId = returnIdByEmail(email);
		Integer appointmentId = Integer.parseInt(appId);
		Iterable<TreatmentDAO> treatments = treatmentRepo.findAllByDoctorId(doctorId);
		for (TreatmentDAO treatment : treatments) {
			if (treatment.getAppointmentId() == appointmentId && treatment.getId() == Integer.parseInt(treatmentId)) {
				treatment.setPrescription(prescription);
				treatmentRepo.save(treatment);
				return true;
			}
		}
		return false;
	}
	
	public void saveTechnicalReports(String email, Help help) {
		Integer id = returnIdByEmail(email);
		help.setUserId(id);
		help.setStatus("Open");
		helpRepo.save(help);
	}
	
	public void onTreatmentCompletion(String email, Integer id) {
		Integer doctorId = returnIdByEmail(email);
		Iterable<Appointment> appointments = appointmentRepo.findByDoctorId(doctorId);
		for (Appointment appointment : appointments) {
			if(appointment.getPatientId().equals(id) && appointment.getStatus().equals("Not Completed")) {
				appointment.setStatus("Completed");
				appointmentRepo.save(appointment);
			}
		}
	}
	
	public boolean treatmentcompleted(String email, Integer id ) {
		Integer doctorId = returnIdByEmail(email);
		Iterable<Appointment> appointments = appointmentRepo.findByDoctorId(doctorId);
		for (Appointment appointment : appointments) {
			if(appointment.getPatientId().equals(id) && appointment.getStatus().equals("Completed")) {
				return true;
			}
		}
		return false;
	}
}
