package com.diagnostic.doctor.dao;

import org.springframework.data.repository.CrudRepository;

public interface TreatmentRepository extends CrudRepository<TreatmentDAO, Integer> {
	
	Iterable<TreatmentDAO> findAllByPatientId(Integer patientId);
	
	Iterable<TreatmentDAO> findAllByDoctorId(Integer doctorId);
	
	Iterable<TreatmentDAO> findByDoctorId(Integer doctorId);

}
