package com.diagnostic.admin.db;

import org.springframework.data.repository.CrudRepository;

public interface TestsRepository extends CrudRepository<TestsDB, Integer> {

	Iterable<TestsDB> findAllByPatientId(Integer patientId);

	Iterable<TestsDB> findAllByDoctorId(Integer doctorId);
	
	Iterable<TestsDB> findByAppointmentId(Integer appointmentId);

//	Iterable<TestsDB> findByServiceName(String service);

}
