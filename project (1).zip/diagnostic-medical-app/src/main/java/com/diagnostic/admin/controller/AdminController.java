package com.diagnostic.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.diagnostic.admin.db.AgentDb;
import com.diagnostic.admin.db.AgentRepository;
import com.diagnostic.admin.db.CommissionDAO;
import com.diagnostic.admin.db.ReviewDAO;
import com.diagnostic.admin.db.ServiceListRepository;
import com.diagnostic.admin.db.ServicesList;
import com.diagnostic.admin.db.TestsDB;
import com.diagnostic.admin.service.AdminService;
import com.diagnostic.patient.controller.PatientService;
import com.diagnostic.patient.dao.Appointment;

@Controller
@SessionAttributes("email")
public class AdminController {

	@Autowired
	private AdminService service;

	@Autowired
	private AgentRepository agentRepo;

	@Autowired
	private ServiceListRepository serviceRepo;
	
	@Autowired
	private PatientService patientService;

	@RequestMapping(value = "/diagnostic-center/adminHome", method = RequestMethod.GET)
	public String showAdminHomePage() {
		return "adminhome";
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/listOfServices", method = RequestMethod.GET)
	public String showServicesPage(ModelMap map) {
		map.put("services", service.listOfServices());
		return "services-list";
	}

	@RequestMapping("/diagnostic-center/adminHome/agentRegistrationPage")
	public String showAgentRegistrationPage(@ModelAttribute("agent") AgentDb agent) {
		return "agent-reg";
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/registerAgent", method = RequestMethod.POST)
	public String AgentRegistration(@ModelAttribute("agent") AgentDb agent, BindingResult result, ModelMap map) {
		if (result.hasErrors()) {
			return "agent-reg";
		}
		map.addAttribute("agent", agent);
		service.createAgent(agent);
		agentRepo.save(agent);
		return "sucess";
	}

	@RequestMapping("/diagnostic-center/adminHome/addService")
	public String showServiceAddPage(@ModelAttribute("servicesList") ServicesList servicesList) {
		return "service-reg";
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/addservice/serviceForm", method = RequestMethod.POST)
	public String serviceRegisterPage(@ModelAttribute("servicesList") ServicesList servicesList, BindingResult result,
			ModelMap map) {
		if (result.hasErrors()) {
			return "service-reg";
		}
		map.addAttribute("servicesList", servicesList);
		service.createService(servicesList);
		serviceRepo.save(servicesList);
		return "redirect:/diagnostic-center/adminHome/listOfServices";
	}

	@RequestMapping("/diagnostic-center/adminHome/updateService")
	public String showServiceUpdatePage() {
		return "update-service";
	}

	@RequestMapping("/diagnostic-center/adminHome/updateServiceByServiceName")
	public String showServiceUpdatePage(@RequestParam String name, @RequestParam String contact,
			@RequestParam String email, ModelMap map) {
		if (service.updateService(name, contact, email)) {
			return "redirect:/diagnostic-center/adminHome/listOfServices";
		}
		map.put("error", "Service name not found");
		return "update-service";
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/approvedAppointments", method = RequestMethod.GET)
	public String showApprovedAppointments(ModelMap map) {
		map.put("appointments", service.approvedAppointments());
		return "admin-appointments";
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/updateTests", method = RequestMethod.GET)
	public String updateTestResults(@RequestParam Integer id, @ModelAttribute("test") TestsDB test, ModelMap map) {
		// System.out.println(id);
		map.put("id", id);
		return "tests-update";
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/updateTestsComplete", method = RequestMethod.POST)
	public String updateTestResults(@ModelAttribute("test") TestsDB tests, ModelMap map, BindingResult result) {
		if (result.hasErrors()) {
			return "tests-update";
		}
		// System.out.println(id);
		map.addAttribute("test", tests);
		service.updateTests(tests);
		return "redirect:/diagnostic-center/adminHome/approvedAppointments";
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/view", method = RequestMethod.GET)
	public String viewTestResults(@RequestParam Integer id, @ModelAttribute("test") TestsDB test, ModelMap map) {
		// map.put("id", id);
		TestsDB testsDB = service.viewTestResult(id);
		System.out.println(testsDB);
		map.addAttribute("test", testsDB);
		return "tests-view";
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/edit", method = RequestMethod.GET)
	public String editTestResultsPage(@RequestParam Integer id, ModelMap map) {
		map.put("id", id);
		return "tests-edit";
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/editResult", method = RequestMethod.POST)
	public String editTestResults(@RequestParam String minValue, @RequestParam String id, ModelMap map) {
		// map.put("id", id);
		if (service.editTestResult(id, minValue)) {
			return "redirect:/diagnostic-center/adminHome/approvedAppointments";
		} else {
			map.put("error", "Appointmnet ID not found");
			return "tests-edit";
		}
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/review", method = RequestMethod.GET)
	public String completedAppointments(@ModelAttribute("appointments") Appointment appointment, ModelMap map) {
		map.addAttribute("appointments", service.completedAppointment());
		return "admin-completed-appointments";
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/review/send", method = RequestMethod.GET)
	public String sendRevieQuestionarie(@RequestParam Integer id, ModelMap map) {
		String email = (String) map.get("email");
		service.sendReviewQuetionarie(email, id);
		return "admin-completed-appointments";
	}

	@RequestMapping(value = "/diagnostic-center/adminHome/agents", method = RequestMethod.GET)
	public String showAgentsBook(@ModelAttribute("appointments") Appointment appointment, ModelMap map) {
		map.addAttribute("appointments",service.agentsWhoGetCommission());
		return "admin-agent";
	}
	
	@RequestMapping(value = "/diagnostic-center/adminHome/agents/booked", method = RequestMethod.GET)
	public String showAgentBookingsById(@RequestParam String id ,@ModelAttribute("appointments") Appointment appointment, ModelMap map) {
		map.addAttribute("appointments",service.agentBookingsById(id));
		return "admin-agent-book";
	}
	
	@RequestMapping(value = "/diagnostic-center/adminHome/agents/addComnission", method = RequestMethod.GET)
	public String addCommissionForm(@RequestParam String id ,@ModelAttribute("commission") CommissionDAO commission, ModelMap map) {
//		map.addAttribute("appointments",service.agentBookingsById(id));
		map.put("id", id);
		return "admin-commission-form";
	}
	
	@RequestMapping(value = "/diagnostic-center/adminHome/agents/addComnission/success", method = RequestMethod.POST)
	public String addCommission(@ModelAttribute("commission") CommissionDAO commission, ModelMap map) {
		String message = service.addCommission(commission);
		map.put("id", commission.getAgentId());
		map.put("message",message);
		return "admin-commission-form";
	}
	

	@RequestMapping("/diagnostic-center/adminHome/updateCommission")
	public String showCommissionUpdatePage() {
		return "update-commission";
	}

	@RequestMapping("/diagnostic-center/adminHome/updateCommissionByServiceName")
	public String commissionUpdatePage(@RequestParam String name, @RequestParam String commission, ModelMap map) {
		if (service.updateCommission(name, commission)) {
			return "redirect:/diagnostic-center/adminHome/listOfServices";
		}
		map.put("error", "Service name not found");
		return "update-commission";
	}
	
	@RequestMapping(value = "/diagnostic-center/adminHome/listOfDoctors", method = RequestMethod.GET)
	public String showDoctorsList(ModelMap map) {
		map.put("doctors", patientService.listOfDoctors());
		return "admin-doctor-details";
	}
	
	@RequestMapping(value = "/diagnostic-center/adminHome/listOfAgents", method = RequestMethod.GET)
	public String showAgentsList(ModelMap map) {
		map.put("agents", service.listOfAgents());
		return "admin-agentdetails";
	}

}
