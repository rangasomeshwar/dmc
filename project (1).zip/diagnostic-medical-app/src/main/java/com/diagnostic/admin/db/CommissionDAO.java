package com.diagnostic.admin.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "commission_table")
public class CommissionDAO {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	private String date;

	@Column(name = "agent_id")
	private Integer agentId;

	private Integer commission;
	private Integer appointments;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Integer getAgentId() {
		return agentId;
	}

	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}

	public Integer getCommission() {
		return commission;
	}

	public void setCommission(Integer commission) {
		this.commission = commission;
	}

	public Integer getAppointments() {
		return appointments;
	}

	public void setAppointments(Integer appointments) {
		this.appointments = appointments;
	}

	@Override
	public String toString() {
		return "CommissionDAO [id=" + id + ", date=" + date + ", agentId=" + agentId + ", commission=" + commission
				+ ", appointments=" + appointments + "]";
	}

}
