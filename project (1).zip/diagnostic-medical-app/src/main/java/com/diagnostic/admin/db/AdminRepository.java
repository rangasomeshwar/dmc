package com.diagnostic.admin.db;

import org.springframework.data.repository.CrudRepository;

public interface AdminRepository extends CrudRepository<AdminDAO, Integer> {

	Iterable<AdminDAO> findByEmail(String email);
}
