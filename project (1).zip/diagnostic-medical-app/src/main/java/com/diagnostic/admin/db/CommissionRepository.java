package com.diagnostic.admin.db;

import org.springframework.data.repository.CrudRepository;

public interface CommissionRepository extends CrudRepository<CommissionDAO, Integer> {

	Iterable<CommissionDAO>	findAllByAgentId(Integer agentId);
	
}
