package com.diagnostic.additional.dao;

import org.springframework.data.repository.CrudRepository;

public interface HelpRepository extends CrudRepository<Help, Integer> {

	Iterable<Help>	findByIssue(String issue);
	
	Iterable<Help>	findByUserId(Integer userId);
	
	Iterable<Help>	findByStatus(String status);
	
}
